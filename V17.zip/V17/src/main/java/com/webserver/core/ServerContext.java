package com.webserver.core;

import servlet.HttpServlet;
import servlet.LoginServlet;
import servlet.RegServlet;
import servlet.ShowAllUserServlet;

import java.util.HashMap;
import java.util.Map;

/**
 * 该类保存所有服务端共用信息
 */
public class ServerContext {
    private static Map<String, HttpServlet> servletMapping=new HashMap<>();

    static{
        initServletMapping();
    }

    private static void initServletMapping(){
        servletMapping.put("/myweb/regUser",new RegServlet());
        servletMapping.put("/myweb/loginUser",new LoginServlet());
        servletMapping.put("/myweb/showAllUser",new ShowAllUserServlet());
    }

    /**
     * 根据请求路径获取对应的Servlet
     * @param path
     * @return
     */
    public static HttpServlet getServlet(String path){
        return servletMapping.get(path);
    }
}
